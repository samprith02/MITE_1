#include <stdio.h>
#include<string.h>

int main()
{   
    int n;
    char type[10];
    int toll=0;
    
    printf("enter the number of vehicles:");
    scanf("%d",&n);
    
  int i=n;
    


    while(i)
    {
        printf("enter the type of vehicle :\n");
        scanf("%s",type);
        
        if(strcmp(type,"car")==0)
        {
            toll=toll+50;
        }
        else if(strcmp(type,"truck")==0)
        {
            toll=toll+100;
        }
        else
        {
            toll=toll+20;
        }
    i--;
    }
    printf("totl collection: %d \n",toll);
    return 0;
}
